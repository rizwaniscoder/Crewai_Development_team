
from crewai import Crew, Process
from langchain_openai import ChatOpenAI
# from decouple import config

from textwrap import dedent
from agents import DevelopmentAgents
from tasks import DevelopmentTasks

from dotenv import load_dotenv
load_dotenv()

class DevelopmentCrew:
    def __init__(self, project_scope):
        self.project_scope = project_scope

    def run(self):
        # Define your custom agents and tasks in agents.py and tasks.py
        agents = DevelopmentAgents()
        tasks = DevelopmentTasks() 

        # Define your custom agents and tasks here
        chief_tech_officer = agents.chief_tech_officer()
        tech_lead = agents.tech_lead()
        flutter_dev = agents.flutter_dev()
        react_dev = agents.react_dev()
        business_analyst = agents.business_analyst()
        tester = agents.tester()
        designer = agents.designer()
        


        # Custom tasks include agent name and variables as input
        define_technological_strategy = tasks.define_technological_strategy(
            chief_tech_officer,
            self.project_scope,
        )

        manage_development_team = tasks.manage_development_team(
            tech_lead,
            self.project_scope,
        )
        
        develop_cross_platform_mobile_app = tasks.develop_cross_platform_mobile_app(
            flutter_dev,
            self.project_scope,
        )
        
        develop_web_and_mobile_applications = tasks.develop_web_and_mobile_applications(
            react_dev,
            self.project_scope,
        )
        
        Conduct_Comprehensive_Testing = tasks.Conduct_Comprehensive_Testing(
            tester,
            self.project_scope,
        )
        
        Gather_and_Analyze_Requirements = tasks.Gather_and_Analyze_Requirements(
            business_analyst,
            self.project_scope,
        )
        
        Create_User_Centric_Designs = tasks.Create_User_Centric_Designs(
            designer,
            self.project_scope,
        )

        # Define your custom crew here
        crew = Crew(
            agents=[chief_tech_officer, tech_lead, flutter_dev, react_dev, business_analyst, tester, designer],
            tasks=[define_technological_strategy, manage_development_team, develop_cross_platform_mobile_app, develop_web_and_mobile_applications, Conduct_Comprehensive_Testing, Gather_and_Analyze_Requirements, Create_User_Centric_Designs],
            process=Process.hierarchical,
            manager_llm=ChatOpenAI(model_name="gpt-3.5-turbo-0125"),
            verbose=True,
        )

        result = crew.kickoff()
        return result




# This is the main function that you will use to run your custom crew.
if __name__ == "__main__":
    print("## Welcome to Technical Crew AI!")
    print("-------------------------------")
    project_scope = input(dedent("""Please provide a complete details and requirements for the project: """))

    custom_crew = DevelopmentCrew(project_scope)
    result = custom_crew.run()
    print("\n\n########################")
    print("## Here is you Development crew run result:")
    print("########################\n")
    print(result)
    
    
    with open("Previous_results.txt", "a") as file:
        file.write("\n\n########################\n")
        file.write("## Here are the previous Development crew result:\n")
        file.write("########################\n")
        file.write(result)


# def main():
#     print("## Welcome to Technical Crew AI!")
#     print("-------------------------------")
#     project_scope = input(dedent("""Please provide a complete details and scope of the project: """))

#     custom_crew = DevelopmentCrew(project_scope)

#     # Redirecting stdout to the file
#     with open("Previous_results.txt", "a") as f:
#         original_stdout = sys.stdout
#         sys.stdout = f

#         # Capturing user input
#         f.write("## User Input:\n")
#         f.write(project_scope + "\n")

#         try:
#             result = custom_crew.run()
#             f.write("\n\n########################\n")
#             f.write("## Here is your Development crew run result:\n")
#             f.write("########################\n")
#             f.write(str(result))
#         except Exception as e:
#             f.write("\n\n########################\n")
#             f.write("## An error occurred during execution:\n")
#             f.write("########################\n")
#             f.write(str(e))

#         # Restoring stdout
#         sys.stdout = original_stdout

#     # Print the output to terminal
#     print("\n\n########################")
#     print("## Here is your Development crew run result:")
#     print("########################\n")
#     print(result)

# if __name__ == "__main__":
#     main()